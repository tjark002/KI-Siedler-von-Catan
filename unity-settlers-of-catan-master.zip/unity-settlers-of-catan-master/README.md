# Settlers_Game
A remake of the board game "Settlers of Catan" for my course at Ohio State University.
